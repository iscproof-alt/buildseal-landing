BuildSeal — fictional procurement record
Record: seal_1792932046613_1cbf006ecbab
Verifier: isc_pack_v5_bin, hosted pack profile 5.1.
This is NOT isc_verify v0.2.0.

Linux/WSL: OpenSSL and compatible system libraries are required.
Run:
  sha256sum -c SHA256SUMS
  sh verify.sh

Public key:
07bef2a88534eddfed032a4d06de927af771affe8975c98c21256a7855bdc03e
SHA-256 public-key fingerprint:
a5ec97589519d9eea3c6985330f601eadcc6f261234636badb0137039bd0a595

The key was cross-checked against the operator's production configuration.
You must decide whether to trust this key.
Checksums detect differences; they do not independently authenticate this download.
The supplied CA file defines the TSA trust anchor.

Strict verification checks content, package root, signature, the supplied
trusted key and TSA verification against the supplied CA trust store.
It does not establish decision correctness, legal qualification,
signer identity certification or record-chain validity.

This fictional content was processed by the BuildSeal server.
Local verification does not demonstrate server-blind encryption.

verifier-source.tar.gz contains the source/build inputs used here.
A reproducible-build equivalence claim is not made.
example-verification.txt is captured output; run verify.sh yourself.
