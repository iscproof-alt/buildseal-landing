#!/bin/sh
set -eu
cd "$(dirname "$0")"
exec ./isc_pack_v5_bin --verify pack.json --content content.json \
  --trusted-key 07bef2a88534eddfed032a4d06de927af771affe8975c98c21256a7855bdc03e --strict
